var app = angular.module('app', []);

//#######################
//JSA CONTROLLER
//#######################

app.controller('jsaController', function($scope, $http, $location) {
	$scope.listCustomers = [];
	
	// $scope.getAllCustomer = 
	function getAllRecord(){
		// get URL
		var url = $location.absUrl() + "api/records/all";
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listCustomers = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getAllRecord();
});

/*app.controller('jsaController_unique', function($scope, $http, $location) {
	$scope.listUniqueRecords = [];
	
	// $scope.getAllCustomer = 
	function getUniqueRecord(){
		// get URL
		var url = $location.absUrl() + "api/records/unique";
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listUniqueRecords = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getUniqueRecord();
});

app.controller('jsaController_dup', function($scope, $http, $location) {
	$scope.listDuplicateRecords = [];
	
	// $scope.getAllCustomer = 
	function getDuplicateRecord(){
		// get URL
		var url = $location.absUrl() + "api/records/duplicate";
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listDuplicateRecords = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getDuplicateRecord();
});*/