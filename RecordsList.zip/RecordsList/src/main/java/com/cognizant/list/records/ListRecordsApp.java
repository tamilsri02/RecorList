package com.cognizant.list.records;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListRecordsApp {

	public static void main(String[] args) {
		SpringApplication.run(ListRecordsApp.class, args);
	}
}
