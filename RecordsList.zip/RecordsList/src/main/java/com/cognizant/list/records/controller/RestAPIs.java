package com.cognizant.list.records.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.list.records.model.Records;

@RestController
@RequestMapping("/api/records")
public class RestAPIs {

	private final static Logger logger = LogManager.getLogger();

	
	@Value("${file.cts.dirName}")
	private  String dirName;

	@Value("${file.cts.fileName}")
	private  String fileName;
	
	Map<Long, Records> recStores = new HashMap<Long, Records>();
	Map<Long, Records> uniqueStores = new HashMap<Long, Records>();
	Map<Long, Records> dupStores = new HashMap<Long, Records>();

	@PostConstruct
	public void initIt() throws Exception {
		String fileToParse = dirName+fileName;
		logger.info("dirName"+dirName);
		logger.info("fileName"+fileName);
		BufferedReader fileReader = null;

		final String DELIMITER = ",";
		String line = "";
		fileReader = new BufferedReader(new FileReader(fileToParse));
		fileReader.readLine();
		int i = 0;
		List<Records> records = new ArrayList<Records>();
		while ((line = fileReader.readLine()) != null) {
			String[] fieldValues = line.split(DELIMITER);
			Records newLine = new Records();
			newLine.setReference(fieldValues[0]);
			newLine.setAccountNumber(fieldValues[1]);
			newLine.setDescription(fieldValues[2]);
			newLine.setStartBalance(fieldValues[3]);
			newLine.setMutation(fieldValues[4]);
			newLine.setEndBalance(fieldValues[5]);
			records.add(newLine);
			recStores.put(Long.valueOf(++i), newLine);
		}
		fileReader.close();
		
		// Preserving List of records to identify duplicates
		List<Records> preserverRecords = new ArrayList<Records>();
		preserverRecords.addAll(records);
		int j=0;

		// Code for unique records
		HashSet<Object> seen = new HashSet<Object>();
		records.removeIf(r -> !seen.add(r.getAccountNumber()));
		for (Records record : records) {
			uniqueStores.put(Long.valueOf(++j), record);
		}
		
		int k=0;
		// Code for duplicate records
		HashMap<String, Object> duplicateRec = new HashMap<String, Object>();
		ArrayList<String> dupAcctnum = new ArrayList<String>();
		for (Records record : preserverRecords) {
			if (duplicateRec.containsKey(record.getAccountNumber())) {
				if (dupAcctnum.contains(record.getAccountNumber())) {
					dupStores.put(Long.valueOf(++k), record);
				} else {
					System.out.println(duplicateRec.get(record.getAccountNumber()));
					dupStores.put(Long.valueOf(++k), record);
					dupAcctnum.add(record.getAccountNumber());
				}
			} else {
				duplicateRec.put(record.getAccountNumber(), record);
			}
		}
	}

	@GetMapping(value = "/all")
	public List<Records> getResource() {

		List<Records> recList = recStores.entrySet().stream().map(entry -> entry.getValue())
				.collect(Collectors.toList());

		return recList;
	}
	
	@GetMapping(value = "/unique")
	public List<Records> getUniqueResource() {

		List<Records> recList = uniqueStores.entrySet().stream().map(entry -> entry.getValue())
				.collect(Collectors.toList());

		return recList;
	}
	
	@GetMapping(value = "/duplicate")
	public List<Records> getDuplicateResource() {

		List<Records> recList = dupStores.entrySet().stream().map(entry -> entry.getValue())
				.collect(Collectors.toList());

		return recList;
	}
}